---
name: Kaldi10 issue
about: This option is for use by core developers only
title: ''
labels: kaldi10-TODO
assignees: ''

---

